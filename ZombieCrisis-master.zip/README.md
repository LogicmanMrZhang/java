# ZombieCrisis
JAVA 射击生存类小游戏

操作说明：
	1P: WASD + J(攻击) + K(切换武器) + L(大招)
	2P: 上下左右 +  1(攻击) + 2(切换武器) + 3(大招)

效果演示：
![demo1](./gif/demo1.gif)  
  
![demo2](./gif/demo2.gif)
